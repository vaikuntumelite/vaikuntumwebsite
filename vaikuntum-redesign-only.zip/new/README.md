# Vaikuntum Stays — redesigned website (v2)

This folder is a complete, self-contained redesign. Nothing outside `new/` was changed.

- Preview after deploy: https://www.vaikuntum.in/new/
- Pages: index.html, vaikuntum-elite.html, sairam.html, aboutus.html, contactus.html
- Styles: assets/site.css · Scripts: assets/site.js (no libraries)
- Photos: img/elite (your 56 4K photos, web-optimised), img/sairam

To make it the live homepage later, copy the contents of `new/` to the site root
(replacing the old pages) once you're happy with it.
