/* Vaikuntum Stays — site interactions (no dependencies) */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var NUM = { elite: '918105148625', sairam: '919741156596' };
  var NAME = { elite: 'Vaikuntum Elite Gents Stay', sairam: 'Sai Ram PG for Gents' };
  var SHARE = { '1': 'Single room', '2': 'Two share', '3': 'Three share', '4': 'Four share' };

  /* year */
  $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* nav: solid after scroll */
  var nav = $('#nav');
  function onScroll() { if (nav && !nav.classList.contains('always')) nav.classList.toggle('solid', window.scrollY > 40); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* mobile menu */
  var mnav = $('#mnav');
  function setMenu(open) {
    if (!mnav) return;
    mnav.classList.toggle('open', open);
    mnav.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.style.overflow = open ? 'hidden' : '';
    $$('.nav .burger').forEach(function (b) { b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
  }
  $$('.nav .burger').forEach(function (b) { b.addEventListener('click', function () { setMenu(true); }); });
  $$('[data-close]', mnav).forEach(function (b) { b.addEventListener('click', function () { setMenu(false); }); });
  $$('a', mnav).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });

  /* reveal on scroll */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.remove('pre'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    var vh = window.innerHeight;
    $$('.rv').forEach(function (el) { if (el.getBoundingClientRect().top > vh) { el.classList.add('pre'); io.observe(el); } });
    /* lazy-load map iframes when near viewport */
    var mo = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting && e.target.dataset.src) { e.target.src = e.target.dataset.src; mo.unobserve(e.target); } });
    }, { rootMargin: '300px' });
    $$('iframe[data-src]').forEach(function (f) { mo.observe(f); });
  } else {
    $$('iframe[data-src]').forEach(function (f) { f.src = f.dataset.src; });
  }
  function loadMaps(scope) { $$('iframe[data-src]', scope).forEach(function (f) { if (!f.src) f.src = f.dataset.src; }); }

  /* generic tabs: [data-tabscope] > [data-tab] + [data-panel] */
  $$('[data-tabscope]').forEach(function (scope) {
    var tabs = $$('[data-tab]', scope);
    tabs.forEach(function (t) {
      t.addEventListener('click', function () {
        tabs.forEach(function (x) { x.setAttribute('aria-selected', x === t ? 'true' : 'false'); });
        $$('[data-panel]', scope).forEach(function (p) {
          var on = p.dataset.panel === t.dataset.tab; p.hidden = !on;
          if (on) { $$('.rv', p).forEach(function (r) { r.classList.remove('pre'); }); loadMaps(p); }
        });
      });
    });
  });

  /* weekly menu: default to today */
  $$('[data-menu]').forEach(function (m) {
    var btns = $$('[data-day]', m);
    function show(i) {
      btns.forEach(function (b) { b.setAttribute('aria-selected', b.dataset.day == i ? 'true' : 'false'); });
      $$('[data-daypanel]', m).forEach(function (p) { p.hidden = p.dataset.daypanel != i; });
    }
    btns.forEach(function (b) { b.addEventListener('click', function () { show(b.dataset.day); }); });
    show((new Date().getDay() + 6) % 7);
  });

  /* room card "+ n more" */
  $$('.incl-toggle').forEach(function (b) {
    var label = b.textContent;
    b.addEventListener('click', function () {
      var ul = b.previousElementSibling, open = ul.classList.toggle('more');
      b.textContent = open ? label : '− Show less';
    });
  });

  /* date inputs: min = today */
  var today = new Date(); today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
  $$('input[type=date]').forEach(function (d) { d.min = today.toISOString().slice(0, 10); });

  /* finder: single rooms only at Sai Ram */
  $$('form.finder').forEach(function (f) {
    var stay = f.elements.stay, single = $('#sh1', f);
    function sync() {
      if (!single) return;
      var isElite = stay.value === 'elite';
      single.disabled = isElite;
      single.nextElementSibling.style.opacity = isElite ? '.35' : '';
      single.nextElementSibling.title = isElite ? 'Single rooms are available at Sai Ram PG' : '';
      if (isElite && single.checked) $('#sh3', f).checked = true;
    }
    stay.addEventListener('change', sync); sync();
  });

  /* enquiry forms -> WhatsApp */
  function fmtDate(v) {
    if (!v) return '';
    var d = new Date(v + 'T00:00:00');
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }
  $$('form[data-enquiry]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var el = f.elements;
      var stay = f.dataset.stay || (el.stay && el.stay.value) || 'elite';
      var share = el.share ? (el.share.value || (f.querySelector('input[name=share]:checked') || {}).value) : '';
      var lines = ['Hi Vaikuntum! I\'m interested in a bed at ' + NAME[stay] + '.'];
      if (share && SHARE[share]) lines.push('Sharing: ' + SHARE[share]);
      if (el.date && el.date.value) lines.push('Move-in: ' + fmtDate(el.date.value));
      if (el.name && el.name.value.trim()) lines.push('Name: ' + el.name.value.trim());
      if (el.phone && el.phone.value.trim()) lines.push('Phone: ' + el.phone.value.trim());
      if (el.msg && el.msg.value.trim()) lines.push(el.msg.value.trim());
      lines.push('Is it available?');
      var url = 'https://wa.me/' + NUM[stay] + '?text=' + encodeURIComponent(lines.join('\n'));
      if (typeof window.fbq === 'function') { try { window.fbq('track', 'Lead', { content_name: NAME[stay] }); } catch (_) {} }
      var w = window.open(url, '_blank', 'noopener');
      var ok = $('.form-ok', f);
      if (!ok) { ok = document.createElement('div'); ok.className = 'form-ok'; ok.setAttribute('role', 'status'); f.appendChild(ok); }
      ok.innerHTML = 'Your message is ready in WhatsApp. <a target="_blank" rel="noopener">Tap here if it didn\'t open</a>.';
      ok.querySelector('a').href = url; ok.classList.add('show');
      void w;
    });
  });

  /* subnav active section */
  var sub = $$('.subnav a');
  if (sub.length && 'IntersectionObserver' in window) {
    var secs = sub.map(function (a) { return $(a.getAttribute('href')); }).filter(Boolean);
    var so = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.isIntersecting) {
          sub.forEach(function (a) {
            var on = a.getAttribute('href') === '#' + e.target.id; a.classList.toggle('on', on);
            if (on && a.scrollIntoView && window.innerWidth < 960) a.parentNode.scrollTo({ left: a.offsetLeft - 16, behavior: 'smooth' });
          });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    secs.forEach(function (s) { so.observe(s); });
  }

  /* gallery filter + show more */
  $$('section[data-gallery]').forEach(function (sec) {
    var btns = $$('[data-filter]', sec), items = $$('.gal-grid [data-open]', sec), more = $('[data-more]', sec), expanded = false;
    function apply(cat) {
      var shown = 0;
      items.forEach(function (it) {
        var match = cat === '*' || it.dataset.cat === cat;
        var visible = match && (expanded || cat !== '*' || shown < 12);
        it.hidden = !visible; if (match) shown++;
      });
      if (more) more.parentNode.hidden = expanded || cat !== '*' || shown <= 12;
    }
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        btns.forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
        apply(b.dataset.filter);
      });
    });
    if (more) more.addEventListener('click', function () { expanded = true; apply('*'); });
    apply('*');
  });

  /* lightbox */
  var lb = $('#lb'), img = $('#lb-img'), cap = $('#lb-cap'), cnt = $('#lb-count'), strip = $('#lb-strip');
  var list = [], idx = 0, lastFocus = null;
  function data(name) {
    var s = document.getElementById('gal-' + name);
    try { return s ? JSON.parse(s.textContent) : []; } catch (_) { return []; }
  }
  function render() {
    var it = list[idx]; if (!it) return;
    img.src = it.src; img.alt = it.cap; cap.textContent = it.cap; cnt.textContent = (idx + 1) + ' / ' + list.length;
    $$('button', strip).forEach(function (b, i) {
      b.classList.toggle('on', i === idx);
      if (i === idx) b.scrollIntoView({ block: 'nearest', inline: 'center' });
    });
    [idx + 1, idx - 1].forEach(function (j) { var n = list[(j + list.length) % list.length]; if (n) { var p = new Image(); p.src = n.src; } });
  }
  function open(name, i) {
    list = data(name); if (!list.length) return;
    idx = Math.max(0, Math.min(i || 0, list.length - 1));
    strip.innerHTML = list.map(function (it, k) { return '<button type="button" data-k="' + k + '" aria-label="Photo ' + (k + 1) + '"><img src="' + it.sm + '" alt="" loading="lazy"></button>'; }).join('');
    lastFocus = document.activeElement;
    lb.classList.add('open'); document.body.style.overflow = 'hidden';
    render(); $('[data-lb-close]', lb).focus();
  }
  function close() { lb.classList.remove('open'); document.body.style.overflow = ''; img.removeAttribute('src'); if (lastFocus) lastFocus.focus(); }
  function step(d) { idx = (idx + d + list.length) % list.length; render(); }
  if (lb) {
    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-open]'); if (!t) return;
      var g = t.closest('[data-gallery]'); if (!g) return;
      e.preventDefault(); open(g.dataset.gallery, +t.dataset.open);
    });
    $('[data-lb-close]', lb).addEventListener('click', close);
    $('.lb-prev', lb).addEventListener('click', function () { step(-1); });
    $('.lb-next', lb).addEventListener('click', function () { step(1); });
    strip.addEventListener('click', function (e) { var b = e.target.closest('[data-k]'); if (b) { idx = +b.dataset.k; render(); } });
    lb.addEventListener('click', function (e) { if (e.target.classList.contains('lb-stage')) close(); });
    document.addEventListener('keydown', function (e) {
      if (!lb.classList.contains('open')) { if (e.key === 'Escape' && mnav && mnav.classList.contains('open')) setMenu(false); return; }
      if (e.key === 'Escape') close(); else if (e.key === 'ArrowRight') step(1); else if (e.key === 'ArrowLeft') step(-1);
    });
    var sx = null;
    lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) { if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) step(dx < 0 ? 1 : -1); sx = null; });
  }
})();
